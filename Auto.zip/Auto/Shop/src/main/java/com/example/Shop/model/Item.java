package com.example.Shop.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table 
public class Item {
    @Id
    private String id;
    @Column
    private String brand;
    @Column
    private String model1;
    @Column
    private String date;
    @Column
    private String deliveryMode;
	public Item()
	{
		
	}
    public Item(String string, String string2, String string3, String string4, String string5) {
        id=string;
		brand = string2;
        model1=string3;
        date=string4;
        deliveryMode=string5;
    }
    
    

    /**
     * @return String return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String return the status
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand the status to set
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * @return String return the location
     */
    public String getModel1() {
        return model1;
    }

    /**
     * @param model1 the location to set
     */
    public void setModel1(String model1) {
        this.model1 = model1;
    }

    /**
     * @return String return the pincode
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date pincode to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return String return the deliveryMode
     */
    public String getDeliveryMode() {
        return deliveryMode;
    }

    /**
     * @param deliveryMode the deliveryMode to set
     */
    public void setDeliveryMode(String deliveryMode) {
        this.deliveryMode = deliveryMode;
    }

}

