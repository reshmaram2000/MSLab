package com.example.Booker.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table 
public class Item {
    @Id
    private String id;
    @Column
    private String status;
    @Column
    private String arrival;
    @Column
    private String dep;
    @Column
    private String date;
	public Item()
	{
		
	}
    public Item(String string, String string2, String string3, String string4, String string5) {
        id=string;
		status = string2;
        arrival=string3;
        dep=string4;
        date=string5;
    }
    
    

    /**
     * @return String return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return String return the location
     */
    public String getArrival() {
        return arrival;
    }

    /**
     * @param arrival the location to set
     */
    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    /**
     * @return String return the pincode
     */
    public String getDep() {
        return dep;
    }

    /**
     * @param dep the pincode to set
     */
    public void setDep(String dep) {
        this.dep = dep;
    }

    /**
     * @return String return the deliveryMode
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the deliveryMode to set
     */
    public void setDate(String date) {
        this.date = date;
    }

}

