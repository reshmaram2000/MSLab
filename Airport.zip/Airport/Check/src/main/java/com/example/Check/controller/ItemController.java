package com.example.Check.controller;

import com.example.Check.model.Item;
import com.example.Check.service.ItemService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/check")
@RestController
public class ItemController {
    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @GetMapping("/get/{itemID}")
    public Item getItem(@PathVariable String itemID) {
        return itemService.getItem(itemID);
    }
}
