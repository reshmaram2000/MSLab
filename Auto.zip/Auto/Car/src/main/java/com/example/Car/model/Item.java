package com.example.Car.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table 
public class Item {
    @Id
    private String id;
    @Column
    private String brand;
    @Column
    private String model1;
	public Item()
	{
		
	}
    public Item(String string, String string2, String string3) {
        id=string;
		brand = string2;
        model1=string3;
    }

    /**
     * @return String return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String return the status
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand the status to set
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * @return String return the location
     */
    public String getModel1() {
        return model1;
    }

    /**
     * @param model1 the location to set
     */
    public void setModel1(String model1) {
        this.model1 = model1;
    }

}

