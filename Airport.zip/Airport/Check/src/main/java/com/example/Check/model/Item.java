package com.example.Check.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table 
public class Item {
    @Id
    private String id;
    @Column
    private String arrival;
    @Column
    private String date;
	public Item()
	{
		
	}
    public Item(String string, String string2, String string3) {
        id=string;
		arrival = string2;
        date=string3;
    }

    /**
     * @return String return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String return the location
     */
    public String getArrival() {
        return arrival;
    }

    /**
     * @param arrival the location to set
     */
    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    /**
     * @return String return the deliveryMode
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the deliveryMode to set
     */
    public void setDate(String date) {
        this.date = date;
    }

}

