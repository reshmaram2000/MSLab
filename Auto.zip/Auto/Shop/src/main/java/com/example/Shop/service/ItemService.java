package com.example.Shop.service;

import com.example.Shop.model.Item;
import com.example.Shop.repository.ItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemService {

    private final ItemRepository itemRepository;

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public Item getItem(String itemID) {
        return itemRepository.findById(itemID).orElse(null);
    }


    public Item create(Item item) {
        return itemRepository.save(item);
    }

    public void delete(String itemId) {
        itemRepository.deleteById(itemId);
    }

    public Item update(Item item,String itemId) {
       Item item1 = itemRepository.findById(itemId).get();
        item1.setBrand(item.getBrand());
        item1.setModel1(item.getModel1());
        item1.setDate(item.getDate());
        item1.setDeliveryMode(item.getDeliveryMode());
        itemRepository.save(item1);
        return item1;
    }

    public void deleteAll() {
        itemRepository.deleteAll();
    }
}
