package com.example.Check;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
