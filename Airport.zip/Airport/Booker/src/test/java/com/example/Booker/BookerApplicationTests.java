package com.example.Booker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookerApplicationTests {

	@Test
	void contextLoads() {
	}

}
